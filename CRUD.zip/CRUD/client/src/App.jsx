import React, { useState, useEffect } from "react";
import "./index.css";
// API base URL
const API_URL = "http://localhost:5000/api/users";

function App() {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [editingUser, setEditingUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true); // Loading indicator

  // Fetch users when the component mounts
  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setIsLoading(true); // Set loading to true before fetching
    try {
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error("Error fetching users:", error);
    } finally {
      setIsLoading(false); // Set loading to false after fetching (success or failure)
    }
  };

  const calculateAge = (dob) => {
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const age = calculateAge(dob);

    if (editingUser) {
      // Update existing user
      try {
        const response = await fetch(`${API_URL}/${editingUser._id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, dob, age }),
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const updatedUser = await response.json();
        setUsers(
          users.map((user) =>
            user._id === updatedUser._id ? updatedUser : user
          )
        );
        setEditingUser(null);
      } catch (error) {
        console.error("Error updating user:", error);
      }
    } else {
      // Create new user
      try {
        const response = await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, dob, age }),
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const newUser = await response.json();
        setUsers([...users, newUser]);
      } catch (error) {
        console.error("Error creating user:", error);
      }
    }
    setName("");
    setDob("");
  };

  const handleEdit = (user) => {
    setEditingUser(user);
    setName(user.name);
    setDob(user.dob);
  };

  const handleDelete = async (id) => {
    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Server error during delete:", errorData);
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      setUsers(users.filter((user) => user._id !== id));
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  return (
    <div>
      <h1 className="title">User Information</h1>
      <form onSubmit={handleSubmit} className="sub">
      <input
          type="text"
          placeholder="Enter name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input"
          required
        />
        <input
          type="date"
          placeholder="Enter date of birth"
          value={dob}
          onChange={(e) => setDob(e.target.value)}
          className="input"
          required
        />
        <button type="submit" className="add">
          {editingUser ? "Update" : "Add"}
        </button>
      </form>
      {isLoading ? (
        <p>Loading users...</p> // Loading indicator
      ) : (
        <table className="table">
          <thead>
          <tr>
            <th>Name</th>
            <th>Date of Birth</th>
            <th>Age</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user._id}>
              <td>{user.name}</td>
              <td>{user.dob}</td>
              <td>{calculateAge(user.dob)}</td>
              <td className="btn">
                <button onClick={() => handleEdit(user)}>Edit</button>
                <button onClick={() => handleDelete(user._id)}>Delete</button>
              </td> 
            </tr>
          ))}
        </tbody>
        </table>
      )}
    </div>
  );
}

export default App;