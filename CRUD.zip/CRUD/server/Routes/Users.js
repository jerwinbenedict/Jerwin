// server/Routes/Users.js
const express = require('express');
const router = express.Router();
const User = require('../Models/User'); // Changed from Item to User

// GET all users
router.get('/', async (req, res) => {
  try {
    const users = await User.find(); // Changed from Item to User
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST a new user
router.post('/', async (req, res) => {
  const user = new User({ // Changed from Item to User
    name: req.body.name,
    dob: req.body.dob,
    age: req.body.age,
  });
  try {
    const newUser = await user.save(); // Changed from newItem to newUser
    res.status(201).json(newUser); // Changed from newItem to newUser
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Middleware to get user by ID
async function getUser(req, res, next) { // Changed from getItem to getUser
  let user; // Changed from item to user
  try {
    user = await User.findById(req.params.id); // Changed from Item to User
    if (!user) { // Changed from item to user
      console.log(`User with ID ${req.params.id} not found.`); // Changed from Item to User
      return res.status(404).json({ message: 'Cannot find user' }); // Changed from item to user
    }
  } catch (err) {
    console.error(`Error finding user with ID ${req.params.id}:`, err); // Changed from item to user
    return res.status(500).json({ message: err.message });
  }
  res.user = user; // Changed from item to user
  next();
}

// GET a single user
router.get('/:id', getUser, (req, res) => { // Changed from getItem to getUser
  res.json(res.user); // Changed from item to user
});

// PUT (update) a user
router.put('/:id', getUser, async (req, res) => { // Changed from getItem to getUser
  if (req.body.name != null) {
    res.user.name = req.body.name; // Changed from item to user
  }
  if (req.body.dob != null) {
    res.user.dob = req.body.dob; // Changed from item to user
  }
  if (req.body.age != null) {
    res.user.age = req.body.age; // Changed from item to user
  }
  try {
    const updatedUser = await res.user.save(); // Changed from item to user, updatedItem to updatedUser
    res.json(updatedUser); // Changed from updatedItem to updatedUser
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE a user
router.delete('/:id', getUser, async (req, res) => { // Changed from getItem to getUser
  try {
    const result = await User.deleteOne({ _id: res.user._id }); // Changed from Item to User, item to user
    if (result.deletedCount === 0) {
      console.log(`User with ID ${req.params.id} was not deleted.`); // Changed from Item to User
      return res.status(404).json({ message: 'User not found or already deleted' }); // Changed from Item to User
    }
    res.json({ message: 'Deleted user' }); // Changed from item to user
  } catch (err) {
    console.error(`Error deleting user with ID ${req.params.id}:`, err); // Changed from item to user
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
